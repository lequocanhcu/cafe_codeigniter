<table class="table table-store table-hover">
    <thead>
        <tr>
            <th class="text-center ind">#</th>
            <th>Tên Kho</th>
            <th>Tổng thu</th>
            <th>Tổng chi</th>
            <th>Sổ Quỹ</th>
        </tr>
    </thead>
    <tbody>
    <?php echo $data; ?>
    </tbody>
</table>