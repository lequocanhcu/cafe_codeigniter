<div class="col-md-8 col-md-offset-2">
    <div class="panel panel-succcess">
        <div class="panel-heading">
            <h3 class="panel-title">Thông báo!</h3>
        </div>
        <div class="panel-body">
            <p>Link liên kết đã hết hạn.</p>

            <div role="alert" class="alert alert-warning ">
                <strong><span class="glyphicon glyphicon-edit"></span></strong>Link đã hết hạn do quá thời gian hoặc
                email nhập không chính xác.
            </div>
            <p class="text-center">
                <a href="authentication/fg_password">
                    <button class="btn btn-primary">Nhập lại email</button>
                </a>
            </p>
            <div class="alert text-center w-hotline" role="alert">
                <h3>Liên hệ với chúng tôi nếu cần hỗ trợ </h3>
                <span class="glyphicon glyphicon-earphone"></span>Tổng đài: <strong class="hotline">01257388742</strong>
                <br>
                <span class="glyphicon glyphicon-phone"></span>Hotline: <strong class="hotline">01257388742</strong>

            </div>
        </div>
    </div>
</div>